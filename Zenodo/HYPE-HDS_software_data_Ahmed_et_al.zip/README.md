# HYPE-HDS
A repo for the HYPE-HDS software and model files for the paper entitled "Implementing A Parsimonious Variable Contributing Area Algorithm for Prairie Pothole Region in the HYPE Modelling Framework" by Ahmed et al.

The code was tested on the Smith Creek Research Basin (SCRB) and St Denis National Wildlife Area above pond 90 (SDNWA-90). The calibrated model setup is available in the [`SCRB_SDNWA90_files`](SCRB_SDNWA90_files) folder.

Use description:
To use the HDS algorithm the "modeloption connectivity 2" has to be set in info.txt. Otherwise only original ilakes are simulated. The subbasins which should be simulated with HDS need to have an ilake SLC area fraction given in GeoData.txt. For ilregions without potholes, the parameter (hdsdepth) or SLC fraction must be set to zero.
HDS depth can be added as input in GeoData.txt (hds_depth column) or par.txt (hdsdepth). The hdsdepth input replaces the lakedepth of the ilake and is used in the HDS algorithm. The input is also used as a flag for which subbasins use the HDS algorithm.